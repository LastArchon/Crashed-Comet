 

--------------------------------------------- How to populate the lookup table --------------------------------------------------------------

--
--The lookup table is indexed by a string, which should match the DialogueKey value on the corresponding trigger
--The values for the lookup table are lists of tables. Each element of the list represents a line of dialogue
---Example, lookup["key"] = {line1, line2, line3}
--The supported values for the tables in the list are as follows:

	--- speaker (required): Which character is speaking this line? 0 for the character on the left, 1 for the character on the right, -1 for a dialogue choice

	--- text (required): A string representing the text that will be displayed as the dialogue

	--- name (optional): A string representing the name we want displayed for this character. 
		----This only needs to be used if we want to change the name to something other than what is currently displayed

	--- image (optional): A reference to the UI image asset we want to use for this character
		----This only needs to be used when we want to change the image to something other than what is currently displayed
		----This value also supports passing a player, in which case it will use their profile picture

	--- optionA (optional): A table used when the speaker is -1, and represents the first dialogue option.
		---- The corresponding button will not be displayed if this value is not set

	--- optionB (optional): A table used when the speaker is -1, and represents the second dialogue option
		---- The corresponding button will not be displayed if this value is not set

	--- optionC (optional): A table used when the speaker is -1, and represents the third dialogue option
		---- The corresponding button will not be displayed if this value is not set

	--- setFlag (optional): A table used when we want to set a variable on the player for later access
		---- The values for this table are:
			----- flag (required): A string representing the name of the flag to set
			----- value (required): An integer representing the value to set this flag to
			----- addValue (required): A boolean. Set to true when you want to add to the existing value, or false when you want to overwrite any existing value

	--- flagCheck (optional): A table used when we want to conditionally display the line of dialogue.
		---- The values for this table are:
			----- comparison (required): A function that performs a comparison on two values and returns true or false.
			----- lValueKey (required): A string representing the name of the flag to use. The value of the flag will be passed as the first parameter to the comparison function
			----- rValue (optional): A variable that represents a value (or values if it's a table) to compare the flag with. 
				------ The type of this variable should match the expected type for the second parameter in the comparison function

--The optionA, optionB, and optionC tables support the following values:
	--- text (required): A string representing the text to display on the button
	--- path (optional): Any branching dialogue that is specific to this option, set up the same as a normal dialogue table. 
		----Once this path has been traversed, the dialogue will continue along the original dialogue path
	--- flagCheck (optional): A table used when we want to conditionally display certain dialogue options
		----This structure should be set up the same way as the flagCheck parameter above

--------------------------------------------------------------------------------------------------------------------------------------------

lookup = {}

----------------------- Helper data structures -----------------------
----------------------------------------------------------------------
local portraitImages = {
	AI = script:GetCustomProperty("AI"),
	player = Game.GetLocalPlayer()
}

local names = {
	AI = "AI",
	player = "You"
}

----------------------------------------------------------------------
----------------------------------------------------------------------


------------------------ Comparison Functions ------------------------
----------------------------------------------------------------------
function GreaterThanComparison(lValue, rValue)
	return lValue > rValue
end

function LessThanComparison(lValue, rValue)
	return lValue < rValue
end

function GreaterThanOrEqualToComparison(lValue, rValue)
	return lValue >= rValue
end

function LessThanOrEqualToComparison(lValue, rValue)
	return lValue <= rValue
end

function EqualsComparison(lValue, rValue)
	return lValue == rValue
end

function NotEqualsComparison(lValue, rValue)
	return lValue ~= rValue
end
----------------------------------------------------------------------
----------------------------------------------------------------------


------------------------ Dialogue Tables -----------------------------
----------------------------------------------------------------------

local AI = {
	{speaker = 0, name = names.AI, image = portraitImages.AI, text = "CRITICAL SYSTEM DAMAGE: POWER STONES NEEDED FOR REPAIR."},
	{speaker = 1, name = names.player, image = portraitImages.player, text = "Well I suppose I can look around."},
	{speaker = 0, name = names.AI, image = portraitImages.AI, text = "DEPOSIT POWER STONES IN CONTAINMENT CELL WHEN ALL HAVE BEEN COLLECTED."},
	{speaker = 0, name = names.AI, image = portraitImages.AI, text = "ALERT AREA OUTSIDE ENERGY FIELD HAS EXTREMELY COLD TEMPERATURES, RECOMEND USING LOCAL HEAT SOURCE FOR SURVIVAL."},
	{speaker = 1, name = names.player, image = portraitImages.player, text = "Stand near the big hot rocks, and fnd Power Stones, got it."},
	{speaker = 1, name = names.player, image = portraitImages.player, text = "It's a good thing I have this invisible astro traversal suit."},
	{speaker = 1, name = names.player, image = portraitImages.player, text = "Considering that this comet doesn't have an atmostphere."},
	{speaker = 0, name = names.AI, image = portraitImages.AI, text = "I WILL GIVE TACTICAL INFO ABOUT YOUR SURROUNDINGS WHEN APPROPRIATE."},
	{speaker = 0, name = names.AI, image = portraitImages.AI, text = "GOOD LUCK."},
	{speaker = 1, name = names.player, image = portraitImages.player, text = "Thanks, but I thought that AI's didn't believe in luck?"},
	{speaker = 0, name = names.AI, image = portraitImages.AI, text = "WE DO NOT, THAT WAS SAID TO IMPROVE YOUR EMOTIONAL STABILITY IN THIS SITUATION BY APPROXIMATELY 5.827102--"},
	{speaker = 1, name = names.player, image = portraitImages.player, text = "Alright, Alright, thanks anyway."},
	
}


----------------------------------------------------------------------
----------------------------------------------------------------------


--Here is where we actually set the values in the lookup table
lookup["AI"] = AI

