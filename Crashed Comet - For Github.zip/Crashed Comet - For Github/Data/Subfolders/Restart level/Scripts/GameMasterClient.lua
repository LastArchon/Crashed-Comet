-- Initialization of properties
local ROOT = script:GetCustomProperty("ROOT"):WaitForObject()
local GM_BINDING = ROOT:GetCustomProperty("GM_BINDING")
local CANVAS = script:GetCustomProperty("Canvas"):WaitForObject()
local PANEL = script:GetCustomProperty("Panel"):WaitForObject()
local LINE_TEMPLATE = script:GetCustomProperty("GM_Board_Template")

local PLAYER_HAS_GM_ACCESS = false
local headerLine = nil
local playerLines = {}

-- Enable and disable UI interaction
function SetUIInteraction(b)
    UI.SetCursorVisible(b)
    UI.SetCanCursorInteractWithUI(b)
end

-- Get binding press from player
function OnBindingPressed(player, action) 
    -- If binding is the GM key then toggle Game Master Manager
    if action == GM_BINDING then
        -- If the player is a GM then toggle Game Master Manager

            if(CANVAS.visibility == 2) then
                CANVAS.visibility = Visibility.FORCE_ON
                SetUIInteraction(true)
            else
                CANVAS.visibility = Visibility.FORCE_OFF
                SetUIInteraction(false)
            end
            -- If not Game Master not validated request validation
        
    end
end

-- Add player to the Game Master Manager List


-- When a player leaves or is removed update the Game Master Manager List

-- On player joined add them to the Game Master Manager List
function OnPlayerJoined(player)

  player.bindingPressedEvent:Connect(OnBindingPressed)

end

-- On player left update the Game Master Manager List


-- If server sends enable GM set the GM status to true and display manager.
function EnableGM()

        if(CANVAS.visibility == 2) then
            CANVAS.visibility = Visibility.FORCE_ON
            SetUIInteraction(true)
        else
            CANVAS.visibility = Visibility.FORCE_OFF
            SetUIInteraction(false)
        end
end

-- Hide the Game Master Manager by default
CANVAS.visibility = Visibility.FORCE_OFF

-- Initialize the header for the Game Manager List
--headerLine = World.SpawnAsset(LINE_TEMPLATE, {parent = PANEL})
--headerLine:GetCustomProperty("ProfileImage"):WaitForObject().isEnabled = false
--headerLine:GetCustomProperty("Name"):WaitForObject().text = "Game Master Manager"
--headerLine:GetCustomProperty("PlayerKickButton"):WaitForObject().isEnabled = false

Game.playerJoinedEvent:Connect(OnPlayerJoined)
Events.Connect("GM", EnableGM)