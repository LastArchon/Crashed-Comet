function restart (player)

    player:SetResource("x", 0)
    player:SetResource("y", 0)
    player:SetResource("z", 0)
    player:SetResource("level", 0)
    player:Die()
    Events.BroadcastToPlayer(player,"startcourse")
 
end    


Events.ConnectForPlayer("restart", restart)