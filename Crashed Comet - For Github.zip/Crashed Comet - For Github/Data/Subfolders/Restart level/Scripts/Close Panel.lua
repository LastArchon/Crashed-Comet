local button = script.parent
local panel = script:GetCustomProperty("panel"):WaitForObject()

function OnClicked(whichButton)
	print("button clicked: " .. whichButton.name)
	panel.visibility = Visibility.FORCE_OFF
    panel.collision = Collision.FORCE_OFF
end

function OnHovered(whichButton)
	--print("button hovered: " .. whichButton.name)
end

function OnUnhovered(whichButton)
	--print("button unhovered: " .. whichButton.name)
end

button.clickedEvent:Connect(OnClicked)
button.hoveredEvent:Connect(OnHovered)
button.unhoveredEvent:Connect(OnUnhovered)
